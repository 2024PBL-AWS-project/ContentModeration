import boto3
import json
import logging
from datetime import datetime
from decimal import Decimal

# Initialize logging
logging.basicConfig(level=logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb', region_name='us-west-2')
sns = boto3.client('sns', region_name='us-west-2')
rekognition = boto3.client('rekognition', region_name='us-west-2')
kinesis_video = boto3.client('kinesisvideo', region_name='us-west-2')

def lambda_handler(event, context):
    """
    Lambda handler function to process video streams through Rekognition.
    """
    logging.info("Received event: %s", json.dumps(event))
    
    try:
        # Get Kinesis Video stream ARN
        stream_name = event['detail']['streamName']
        stream_arn = f"arn:aws:kinesisvideo:us-west-2:794038244518:stream/{stream_name}"
        
        # Create stream processor if it doesn't exist
        processor_name = f"content-moderation-{stream_name}"
        try:
            response = rekognition.create_stream_processor(
                Name=processor_name,
                Input={
                    'KinesisVideoStream': {
                        'Arn': stream_arn
                    }
                },
                Output={
                    'KinesisDataStream': {
                        'Arn': stream_arn
                    }
                },
                RoleArn='arn:aws:iam::794038244518:role/content-moderation-role',
                Settings={
                    'ContentModeration': {
                        'MinConfidence': 80
                    }
                }
            )
        except rekognition.exceptions.ResourceInUseException:
            # Stream processor already exists
            pass
        
        # Start the stream processor
        response = rekognition.start_stream_processor(
            Name=processor_name
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'ProcessorName': processor_name,
                'Message': 'Content moderation stream processor started successfully'
            })
        }
        
    except Exception as e:
        logging.error(f"Error processing event: {str(e)}")
        raise